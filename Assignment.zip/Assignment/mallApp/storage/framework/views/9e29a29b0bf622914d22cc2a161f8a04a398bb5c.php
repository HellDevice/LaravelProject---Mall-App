<?php

	use App\Dictionary;
	use App\tenant;

?>
<head><h1>Lot Rental Detail :</h1></head>
<nav>
    <ul>
        <li><a href="/tenant/create">Register Tenant</a></li>
        <li><a href="/lot/create">Rent Lot</a></li>
        <li><a href="/tenant">View Tenant Detail</a></li>
        <li><a class="active" href="/lot">View Lot Detail</a></li>
    </ul>
</nav>


<?php $__env->startSection('content'); ?>
<!-- Bootstrap Boilerplate... -->
<div class="panel-body">
<?php if(count($lots) > 0): ?>
<table class="table table-striped task-table">
<!-- Table Headings -->
<thead>
<tr>
<th>No.</th>
<th>Lot No.</th>
<th>Store Name</th>
<th>Department</th>
<th>Level</th>
<th>Tenant ID</th>
<th>Action</th>
</tr>
</thead>

<!-- Table Body -->
<tbody>
<?php $__currentLoopData = $lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td class="table-text">
<div><?php echo e($i+1); ?></div>
</td>
<td class="table-text">
<div>
<?php echo link_to_route(
'lot.show',
$title = $lot->lot_no,
$parameters = [
'id' => $lot->id,
]
); ?>

</div>
</td>

<td class="table-text">
<div><?php echo e($lot->store_name); ?></div>
</td>

<td class="table-text">
<div><?php echo e(Dictionary::$departments[$lot->department]); ?></div>
</td>

<td class="table-text">
<div><?php echo e(Dictionary::$levels[$lot->level]); ?></div>
</td>

<td class="table-text">
<div><?php echo e($lot->tenant_id); ?></div>
</td>

<td class="table-text">
<div>
<?php echo link_to_route(
'lot.edit',
$title = 'Edit',
$parameters = [
'id' => $lot->id,
]
); ?>

<!--
<?php echo Form::open(['method' => 'DELETE', 'route' => ['lot.destroy', $lot->id]]); ?>

<?php echo Form::submit('Delete'); ?>

-->
<a href="<?php echo e(route('lot.delete', $lot->id)); ?>">Delete</a>
</div>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<br/>
<footer>
<a href = '/lot/create'>Add New</a>
</footer> 
<?php else: ?>
<div>
No records found
</div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>