<!DOCTYPE html>
<html lang="en">
<head>
    <title>Traveller Mall</title>

<!-- CSS And JavaScript -->
<style>
            head{
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            }
            body{
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            }
            footer{
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            }
</style>
</head>

<body>
    <div class="container">
        <nav class="navbar navbar-default">
            <!-- Navbar Contents -->
        </nav>
    </div>

    @yield('content')
</body>
</html>