<?php

	use App\Dictionary;

?>
<head><h1>Navigator</h1></head>
<nav>
    <ul>
        <li><a class="active" href="/lot/level">Order By Level</a></li>
        <li><a href="/lot/department">Order By Department</a></li>
        <li><a href="/lot/store_name">Order By Store Name</a></li>
    </ul>
</nav>
@extends('layouts.frontEnd')

@section('content')
<!-- Bootstrap Boilerplate... -->
<div class="panel-body">
@if (count($lots) > 0)
<table class="table table-striped task-table">
<!-- Table Headings -->
<thead>
<tr>
<th>No.</th>
<th>Lot No.</th>
<th>Store Name</th>
<th>Department</th>
<th>Level</th>
</tr>
</thead>

<!-- Table Body -->
<tbody>
@foreach ($lots as $i => $lot)
<tr>
<td class="table-text">
<div>{{ $i+1 }}</div>
</td>
<td class="table-text">
<div>
{!! link_to_route(
'lot.show',
$title = $lot->lot_no,
$parameters = [
'id' => $lot->id,
]
) !!}
</div>
</td>

<td class="table-text">
<div>{{ $lot->store_name }}</div>
</td>

<td class="table-text">
<div>{{ Dictionary::$departments[$lot->department] }}</div>
</td>

<td class="table-text">
<div>{{ Dictionary::$levels[$lot->level] }}</div>
</td>

</div>
</td>
</tr>
@endforeach
</tbody>
</table>
<br/>
<footer>
</footer> 
@else
<div>
No records found
</div>
@endif
</div>
@endsection