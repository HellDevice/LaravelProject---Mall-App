<?php
?>
<head><h1>New Tenant Registration</h1></head>
<nav>
    <ul>
        <li><a class="active" href="/tenant/create">Register Tenant</a></li>
        <li><a href="/lot/create">Rent Lot</a></li>
        <li><a href="/tenant">View Tenant Detail</a></li>
        <li><a href="/lot">View Lot Detail</a></li>
    </ul>
</nav></br></br>
@extends('layouts.app')

@section('content')

<!-- Bootstrap Boilerplate... -->

<div class="panel-body">
<!-- New tenant Form -->
{!! Form::model($tenant, [
'route' => ['tenant.store'],
'class' => 'form-horizontal'
]) !!}

<!-- tenant_id -->
<div class="form-group_row">
{!! Form::label('tenant-tenant_id', 'Tenant ID :', [
'class' => 'control-label col-sm-3',
]) !!}
<div class="col-sm-9">
{!! Form::text('tenant_id', null, [
'id' => 'tenant-tenant_id',
'class' => 'form-control',
'maxlength' => 5,
]) !!}
</div>
</div></br>

<!-- tenant_name -->
<div class="form-group_row">
{!! Form::label('tenant-tenant_name', 'Tenant Name :', [
'class' => 'control-label col-sm-3',
]) !!}
<div class="col-sm-9">
{!! Form::text('tenant_name', null, [
'id' => 'tenant-tenant_name',
'class' => 'form-control',
'maxlength' => 100,
]) !!}
</div>
</div></br>

<!-- tenant_contact -->
<div class="form-group_row">
{!! Form::label('tenant-tenant_contact', 'Tenant Contact :', [
'class' => 'control-label col-sm-3',
]) !!}
<div class="col-sm-9">
{!! Form::text('tenant_contact', null, [
'id' => 'tenant-tenant_contact',
'class' => 'form-control',
'maxlength' => 100,
]) !!}
</div>
</div></br>

<!-- tenant_email -->
<div class="form-group_row">
{!! Form::label('tenant-tenant_email', 'Tenant Email :', [
'class' => 'control-label col-sm-3',
]) !!}
<div class="col-sm-9">
{!! Form::text('tenant_email', null, [
'id' => 'tenant-tenant_email',
'class' => 'form-control',
'maxlength' => 100,
]) !!}
</div>
</div></br>

<!-- tenant_address -->
<div class="form-group_row">
{!! Form::label('tenant-tenant_address', 'Tenant Address :', [
'class' => 'control-label col-sm-3',
]) !!}
<div class="col-sm-9">
{!! Form::textarea('tenant_address', null, [
'id' => 'tenant-tenant_address',
'class' => 'form-control',
]) !!}
</div>
</div></br>

<!-- Submit Button -->
<div class="form-group_row">
<div class="col-sm-offset-3_col-sm-6">
	{!! Form::button('Register', [
	'type' => 'submit',
	'class' => 'btn_btn-primary',
	]) !!}
</div>
</div></br>
{!! Form::close() !!}
</div>

@endsection