<?php

	use App\Dictionary;

?>
<head><h1>Tenants' Detail</h1><head>
<nav>
    <ul>
        <li><a href="/tenant/create">Register Tenant</a></li>
        <li><a href="/lot/create">Rent Lot</a></li>
        <li><a class="active" href="/tenant">View Tenant Detail</a></li>
        <li><a href="/lot">View Lot Detail</a></li>
    </ul>
</nav>
@extends('layouts.app')

@section('content')
<!-- Bootstrap Boilerplate... -->
<div class="panel-body">
@if (count($tenants) > 0)
<table class="table table-striped task-table">
<!-- Table Headings -->
<thead>
<tr>
<th>No.</th>
<th>Tenant ID.</th>
<th>Tenant Name</th>
<th>Tenant Contact</th>
<th>Tenant Email</th>
<th>Tenant Address</th>
<th>Actions</th>
</tr>
</thead>

<!-- Table Body -->
<tbody>
@foreach ($tenants as $i => $tenant)
<tr>
<td class="table-text">
<div>{{ $i+1 }}</div>
</td>
<td class="table-text">
<div>
{!! link_to_route(
'tenant.show',
$title = $tenant->tenant_id,
$parameters = [
'id' => $tenant->id,
]
) !!}
</div>
</td>
<td class="table-text">
<div>{{ $tenant->tenant_name }}</div>
</td>
<td class="table-text">
<div>{{ $tenant->tenant_contact }}</div>
</td>
<td class="table-text">
<div>{{ $tenant->tenant_email }}</div>
</td>
<td class="table-text">
<div>{{ $tenant->tenant_address }}</div>
</td>
<td class="table-text">
<div>
{!! link_to_route(
'tenant.edit',
$title = 'Edit',
$parameters = [
'id' => $tenant->id,
]
) !!}
|
<!--{!!
 Form::open(['method' => 'DELETE', 'route' => ['tenant.destroy', $tenant->id]]) 
!!}
{!!
	Form::submit('Delete')
!!}
-->
<a href="{{ route('tenant.delete', $tenant->id) }}">Delete</a>
</div>
</td>
</tr>
@endforeach
</tbody>
</table>
<br/>
<footer>
<a href = '/tenant/create'>Add New</a> 
</footer>
@else
<div>
No records found
</div>
@endif
</div>
@endsection