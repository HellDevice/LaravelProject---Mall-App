<?php

	use App\Dictionary;
	use App\tenant;

?>
<head><h1>Lot Rental Detail :</h1></head>
<nav>
    <ul>
        <li><a href="/lot/level">Sort By Level</a></li>
        <li><a class="active" href="/lot/department">Sort By Department</a></li>
        <li><a href="/lot/storeName">Sort By Store Name</a></li>
    </ul>
</nav>
@extends('layouts.app')

@section('content')
<!-- Bootstrap Boilerplate... -->
<div class="panel-body">
@if (count($lots) > 0)
<table class="table table-striped task-table">
<!-- Table Headings -->
<thead>
<tr>
<th>No.</th>
<th>Lot No.</th>
<th>Store Name</th>
<th>Department</th>
<th>Level</th>

</tr>
</thead>

<!-- Table Body -->
<tbody>
@foreach ($lots as $i => $lot)
<tr>
<td class="table-text">
<div>{{ $i+1 }}</div>
</td>
<td class="table-text">
<div>{{ $lot->lot_no }}</div>
</td>

<td class="table-text">
<div>{{ $lot->store_name }}</div>
</td>

<td class="table-text">
<div>{{ Dictionary::$departments[$lot->department] }}</div>
</td>

<td class="table-text">
<div>{{ Dictionary::$levels[$lot->level] }}</div>
</td>

<td class="table-text">
<div>{{ $lot->tenant_id }}</div>
</td>
</tr>
@endforeach
</tbody>
</table>
<br/>
 
@else
<div>
No records found
</div>
@endif
</div>
@endsection