<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tenant extends Model
{
    //
    protected $fillable = [
		'tenant_id',
		'tenant_name',
		'tenant_contact',
		'tenant_email',
		'tenant_address',
	];
}
