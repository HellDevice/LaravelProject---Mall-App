<?php

namespace App;

class Dictionary
{
	public static $departments = [
		'001' => 'Bar and Restaurant',
		'002' => 'Grocery',
		'003' => 'Sport',
		'004' => 'Fashion',
		'005' => 'Life Style',
		'006' => 'Furniture',
		'007' => 'Book Store',
		'008' => 'Entertainment',
		'009' => 'Service',
		'010' => 'Gadget',
		'011' => 'Hardware',
		'012' => 'Accessories',
	];
	
	public static $levels = [
		'00' => 'Basemant',
		'01' => 'Ground Floor',
		'02' => 'Mezzanine Floor',
		'03' => 'Level 1',
		'04' => 'Level 2',
		'05' => 'Level 3',
		'06' => 'Level 4',
		'07' => 'Level 5',
		'08' => 'Level 6',
		'09' => 'Level 7',
		'10' => 'Level 8',
	];
	

}