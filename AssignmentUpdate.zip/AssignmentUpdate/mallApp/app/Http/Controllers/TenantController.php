<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Tenant;

class TenantController extends Controller
{
    //
    public function create()
	{
		$tenant = new Tenant();

		return view('tenants.create', [
		'tenant' => $tenant,
		]);
	}
	
	public function store(Request $request)
	{
		$tenant = new Tenant;
		$tenant->fill($request->all());
		$tenant->save();
	
		return redirect()->route('tenant.index');
	}
	
	public function index()
	{
		$tenants = Tenant::orderBy('tenant_name', 'asc')->get();

		return view('tenants.index', [
		'tenants' => $tenants
		]);
	}
	
	public function show($id)
	{
		$tenant = Tenant::find($id);
		if(!$tenant) throw new ModelNotFoundException;
	
		return view('tenants.show', [
		'tenant' => $tenant
		]);
	}
	
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */	
	public function edit($id)
	{
		$tenant = Tenant::find($id);
		if(!$tenant) throw new ModelNotFoundException;

		return view('tenants.edit', [
		'tenant' => $tenant
		]);
	}
	
	public function update(Request $request, $id)
	{
		$tenant = Tenant::find($id);
		if(!$tenant) throw new ModelNotFoundException;
		$tenant->fill($request->all());
		$tenant->save();
		return redirect()->route('tenant.index');
	}
	
	public function destroy($id)
    {
		$tenant = Tenant::find($id);
        $tenant->delete(); 
        return redirect()->route('tenant.index')->with('success','Tenant deleted successfully');

    }

}
