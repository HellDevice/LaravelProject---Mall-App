<!DOCTYPE html>
<html lang="en">
    <head>
        <title>The Traveller Mall Manager</title>
        <!-- CSS And JavaScript -->
        <style>
            head{
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            }
            body{
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            }
            footer{
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            }
            input[type=text], select {
                width: 100%;
                padding: 12px 20px;
                margin: 8px 0;
                display: inline-block;
                border: 1px solid #ccc;
                border-radius: 4px;
                box-sizing: border-box;
            }

            button {
                width: 100%;
                background-color: #4CAF50;
                color: white;
                padding: 14px 20px;
                margin: 8px 0;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }

            button:hover {
                background-color: orangered;
            }

            body table a:link, body table a:visited {
                background-color: #006400;
                color: white;
                padding: 14px 25px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
            }

            body table a:hover, body table a:active {
                background-color: lime;
                color: black;
            }

            footer a:link, footer a:visited {
                background-color: orangered;
                color: white;
                padding: 14px 25px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
            }

            footer a:hover, footer a:active {
                background-color: orange;
                color: black;
            }

            table {
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                border-collapse: collapse;
                width: 100%;
                border: 1px solid #ddd;
            }
            
            th{
                background-color: #4CAF50;
                text-align: left;
                padding: 8px;
            }
            td {
                text-align: left;
                padding: 8px;
            }

            tr:nth-child(even) {background-color: #f2f2f2;}
            li {
                float: left;
            }
            li a 
            {
                display: block;
                color: white;
                text-align: center;
                padding: 14px 16px;
                text-decoration: none;
            }
            li a:hover{
                display: block;
                color: black;
                text-align: center;
                padding: 14px 16px;
                text-decoration: none;
                background-color: forestgreen;

            }
            .active {
                background-color: #4CAF50;
            }

            ul {
                list-style-type: none;
                margin: 0;
                padding: 0;
                overflow: hidden;
                background-color: #333;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <nav class="navbar navbar-default">
                <!-- Navbar Contents -->
            </nav>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </body>
</html>