<?php?>


<?php $__env->startSection('content'); ?>
<head><h1>Edit Tenant Information</h1></head>
<nav>
    <ul>
        <li><a href="/tenant/create">Register Tenant</a></li>
        <li><a href="/lot/create">Rent Lot</a></li>
        <li><a href="/tenant">View Tenant Detail</a></li>
        <li><a href="/lot">View Lot Detail</a></li>
    </ul>
</nav>

<!-- Bootstrap Boilerplate... -->

<<div class="panel-body">
<!-- New tenant Form -->
<?php echo Form::model($tenant, [
'route' => ['tenant.update',$tenant->id],
'method'=>'put',
'class' => 'form-horizontal'
]); ?>


<!-- tenant_id -->
<div class="form-group_row">
<?php echo Form::label('tenant-tenant_id', 'Tenant ID :', [
'class' => 'control-label col-sm-3',
]); ?>

<div class="col-sm-9">
<?php echo Form::text('tenant_id', null, [
'id' => 'tenant-tenant_id',
'class' => 'form-control',
'maxlength' => 5,
]); ?>

</div>
</div>

<!-- tenant_name -->
<div class="form-group_row">
<?php echo Form::label('tenant-tenant_name', 'Tenant Name :', [
'class' => 'control-label col-sm-3',
]); ?>

<div class="col-sm-9">
<?php echo Form::text('tenant_name', null, [
'id' => 'tenant-tenant_name',
'class' => 'form-control',
'maxlength' => 100,
]); ?>

</div>
</div>

<!-- tenant_contact -->
<div class="form-group_row">
<?php echo Form::label('tenant-tenant_contact', 'Tenant Contact :', [
'class' => 'control-label col-sm-3',
]); ?>

<div class="col-sm-9">
<?php echo Form::text('tenant_contact', null, [
'id' => 'tenant-tenant_contact',
'class' => 'form-control',
'maxlength' => 100,
]); ?>

</div>
</div>

<!-- tenant_email -->
<div class="form-group_row">
<?php echo Form::label('tenant-tenant_email', 'Tenant Email :', [
'class' => 'control-label col-sm-3',
]); ?>

<div class="col-sm-9">
<?php echo Form::text('tenant_email', null, [
'id' => 'tenant-tenant_email',
'class' => 'form-control',
'maxlength' => 100,
]); ?>

</div>
</div>

<!-- tenant_address -->
<div class="form-group_row">
<?php echo Form::label('tenant-tenant_address', 'tenant_address', [
'class' => 'control-label col-sm-3',
]); ?>

<div class="col-sm-9">
<?php echo Form::textarea('tenant_address', null, [
'id' => 'tenant-tenant_address',
'class' => 'form-control',
]); ?>

</div>
</div>

<!-- Submit Button -->
<div class="form-group_row">
<div class="col-sm-offset-3_col-sm-6">
<?php echo Form::button('Update', [
'type' => 'submit',
'class' => 'btn_btn-primary',
]); ?>

</div>
</div>
<?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>