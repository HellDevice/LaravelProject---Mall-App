<?php
use App\Dictionary;
?>
<head><h1>Lot For Rent Update at Traveller Mall</h1></head>
<nav>
    <ul>
        <li><a href="/tenant/create">Register Tenant</a></li>
        <li><a href="/lot/create">Rent Lot</a></li>
        <li><a href="/tenant">View Tenant Detail</a></li>
        <li><a href="/lot">View Lot Detail</a></li>
    </ul>
</nav>


<?php $__env->startSection('content'); ?>
<!-- Bootstrap Boilerplate... -->

<div class="panel-body">
<!-- New lot Form -->
<?php echo Form::model($lot, [
'route' => ['lot.update',$lot->id],
'method'=>'put',
'class' => 'form-horizontal'
]); ?>


<!-- Lot Number-->
<div class="form-group_row">
<?php echo Form::label('lot-lot_no', 'Lot No. :', [
'class' => 'control-label_col-sm-3',
]); ?>

<div class="col-sm-9">
<?php echo Form::text('lot_no', null, [
'id' => 'lot-lot_no',
'class' => 'form-control',
'maxlength' => 5,
]); ?>

</div>
</div></br>

<!-- store_name -->
<div class="form-group_row">
<?php echo Form::label('lot-store_name', 'Store Name :', [
'class' => 'control-label col-sm-3',
]); ?>

<div class="col-sm-9">
<?php echo Form::text('store_name', null, [
'id' => 'lot-store_name',
'class' => 'form-control',
'maxlength' => 100,
]); ?>

</div>
</div></br>

<!-- department -->
<div class="form-group_row">
	<?php echo Form::label('lot-department', 'Department :', [
	'class' => 'control-label col-sm-3',
	]); ?>

<div class="col-sm-9">
	<?php echo Form::select('department', Dictionary::$departments, null, [
	'class' => 'form-control',
	'placeholder' => '- Select department -',
	]); ?>

</div>
</div></br>

<!-- level -->
<div class="form-group_row">
<?php echo Form::label('lot-level', 'Level :', [
'class' => 'control-label_col-sm-3',
]); ?>

<div class="col-sm-9">
<?php echo Form::select('level', Dictionary::$levels, null, [
'id' => 'lot-level',
'class' => 'form-control',
'placeholder' => '- Select level -',
]); ?>

</div>
</div></br>

<!-- tenant_id -->
<div class="form-group_row">
<?php echo Form::label('lot-tenant_id', 'Tenant ID :', [
'class' => 'control-label_col-sm-3',
]); ?>

<div class="col-sm-9">
<?php echo Form::text('tenant_id', null, [
'id' => 'lot-tenant_id',
'class' => 'form-control',
'maxlength' => 5,
]); ?>

</div>
</div></br>

<!-- Submit Button -->
<div class="form-group_row">
<div class="col-sm-offset-3_col-sm-6">
	<?php echo Form::button('Update', [
	'type' => 'submit',
	'class' => 'btn_btn-primary',
	]); ?>

</div>
</div></br>
<?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>